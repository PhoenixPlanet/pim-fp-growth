#ifndef DPU_DEFS_H
#define DPU_DEFS_H

typedef struct dpu_set_t* dpu_set_ptr;

#endif